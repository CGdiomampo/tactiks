<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Hourizon Core
 */

get_header(); ?>
	
	<div id="home-banner" >
		<ul id="slider">
			<li>
				<div class="innerSlide" style="background: url(<?php echo get_stylesheet_directory_uri(); ?>/images/banner1.jpg); background-size: cover;" >
					<div class="container" >
						<div class="caption">
							<p>Denali Concepts Inc. began with the simple idea of providing more outdoor toys to the Filipinos. We believe that playing outdoor toys is a way of bringing back the touch points of health, fitness, and quality time in every individual�s lifestyle.</p>
							<p>Our company lives up to its commitment to quality and affordable products and knowledgeable customer service. It is our mission is to help each customer get the most out of his or her adventures.</p>
						</div>
					</div>
				</div>
			</li>
		</ul>
	</div>

	<div id="primary" class="content-area">
		<div id="main" class="site-main">
			<div id="main-content" class="home-content main-content container">
				<h1>Our Brands</h1>
			</div>
		</div>
	</div><!-- #primary -->
	
<?php get_footer(); ?>
