<?php
// File Security Check
add_action( 'init', 'woo_add_brands', 10 );
if ( ! function_exists( 'woo_add_brands' ) ) {
	function woo_add_brands() 
	{
	  $labels = array(
	    'name' => _x( 'brands', 'post type general name', 'woothemes' ),
	    'singular_name' => _x( 'brands', 'post type singular name', 'woothemes' ),
	    'add_new' => _x( 'Add New', 'brands', 'woothemes' ),
	    'add_new_item' => __( 'Add brands', 'woothemes' ),
	    'edit_item' => __( 'Edit brands', 'woothemes' ),
	    'new_item' => __( 'New brands', 'woothemes' ),
	    'view_item' => __( 'View brands', 'woothemes' ),
	    'search_items' => __( 'Search brands', 'woothemes' ),
	    'not_found' =>  __( 'No brands found', 'woothemes' ),
	    'not_found_in_trash' => __( 'No brands found in Trash', 'woothemes' ), 
	    'parent_item_colon' => '',
		'menu_name'          => 'Brands'
	  );
	  
	  $infobox_rewrite = get_option( 'woo_brands_rewrite' );
	  if( empty( $infobox_rewrite ) ) { $infobox_rewrite = 'brands'; }
	  
	  $args = array(
	    'labels' => $labels,
	    'public' => true,
	    'publicly_queryable' => true,
	    'show_ui' => true, 
	    'query_var' => true,
	    'rewrite' => array( 'slug'=> $infobox_rewrite ),
	    'capability_type' => 'post',
	    'hierarchical' => false,
		'has_archive' => true,
	    'menu_icon' => get_stylesheet_directory_uri() . '/includes/images/box.png',
	    'menu_position' => null,
	    'supports' => array( 'title', 'editor' , 'thumbnail' , 'author', 'thumbnail', /*'excerpt', 'comments'*/ )
	  ); 
	  register_post_type( 'brands', $args );
	}
}


add_action( 'add_meta_boxes', 'brands_price_box' );
function brands_price_box() {
    add_meta_box( 
        'brands_price_box',
        __( 'Url Link', 'myplugin_textdomain' ),
        'brands_price_box_content',
        'brands',
        'normal',
        'low'
    );
}

function brands_price_box_content( $post ) {
 global $post;
	$custom_textfield = get_post_custom($post->ID);
    $brands_price = $custom_textfield["brands_price"][0];  

	wp_nonce_field( plugin_basename( __FILE__ ), 'brands_price_box_content_nonce' );
	echo '<input type="text" id="brands_price" style="width:90%;" name="brands_price" value="'. $brands_price .'"/>';
	echo '</br>';
}

add_action( 'save_post', 'brands_price_box_save' );
function brands_price_box_save( $post_id ) {

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
	return;

	if ( !wp_verify_nonce( $_POST['brands_price_box_content_nonce'], plugin_basename( __FILE__ ) ) )
	return;

	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post_id ) )
		return;
	} else {
		if ( !current_user_can( 'edit_post', $post_id ) )
		return;
	}
	$brands_price = $_POST['brands_price'];
	update_post_meta( $post_id, 'brands_price', $brands_price );
}
 
/**
 * Enqueue scripts and styles.
 */
 
 
 remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display' , 15 );
 remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20  );
 remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );



add_action( 'woocommerce_archive_description', 'woocommerce_category_image', 2 );
function woocommerce_category_image() {
    if ( is_product_category() ){
	    global $wp_query;
	    $cat = $wp_query->get_queried_object();
	    $thumbnail_id = get_woocommerce_term_meta( $cat->term_id, 'thumbnail_id', true );
	    $image = wp_get_attachment_url( $thumbnail_id );
	    if ( $image ) {
		    echo '<img class="ccover" src="' . $image . '" alt="" />';
		}
	}
}

add_filter('add_to_cart_fragments', 'woocommerce_header_add_to_cart_fragment');

function woocommerce_header_add_to_cart_fragment( $fragments ) 
{
    global $woocommerce;
    ob_start(); ?>

	<a id="shopping_cart" class="shopping_cart tog cart-contents" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'woothemes'); ?>"> Cart <span class="item-total"><?php echo $woocommerce->cart->cart_contents_count;?></span></a>
			
    <?php
    $fragments['a.cart-contents'] = ob_get_clean();
    return $fragments;
}




