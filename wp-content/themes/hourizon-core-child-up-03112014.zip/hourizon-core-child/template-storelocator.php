<?php
/**
 * Template Name: Store Locator Page
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package denali
 */

get_header(); 

wp_reset_postdata();
?>
	

	<section id="blog-loop" class="section-wide" role="main">
	
		<main id="main" class="site-main" role="main">
		<div id="main-content" class="page-content main-content container">
         <h1 class="entry-title"> <?php  the_title(); ?>  </h1>  
	
		<div class="row">
			<div class="col-xs-6 col-md-4">
				<div class="stbox" >
				<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo1.jpg" /></a>
				<ul>
					<li><p>SM Toy Kingdom</p></li>
					<li><p>Planet Sports</p></li>
					<li><p>Island Souvenirs</p></li>
					<li><p>R.O.X.</p></li>
					<li><p>Chris Sports</p></li>
					<li><p>Hobbes &amp; Landes</p></li>
					<li><p>Dash</p></li>
					<li><p>Lazada Philippines</p></li>
				</ul>
				</div>
			</div>
			<div class="col-xs-6 col-md-4">
				<div class="stbox" >
					<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo2.jpg" /></a>
					<ul>
						<li><p>Yardstick Coffee</p></li>
						<li><p>Lazada Philippines</p></li>
					</ul>
				</div>
			</div>
			<div class="col-xs-6 col-md-4">
				<div class="stbox" >
					<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo3.jpg" /></a>
					<ul>
						<li><p>Market! Market! (kiosk)</p></li>
						<li><p>R.O.X.</p></li>
					</ul>
				</div>
			</div>
		</div>
	
		<div class="row" style="margin-bottom: 21px;">
			<div class="col-xs-6 col-md-4">
				<div class="stbox" >
				<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo4.jpg" /></a>
				<ul>
					<li><p>Island Souvenirs</p></li>
					<li><p>R.O.X.</p></li>
					<li><p>Zalora Philippines</p></li>
				</ul>
				</div>
			</div>
			<div class="col-xs-6 col-md-4">
				<div class="stbox" >
					<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo5.jpg" /></a>
					<ul>
						<li><p>Market! Market! (kiosk)</p></li>
						<li><p>Island Souvenirs</p></li>
						<li><p>Lazada Philippines</p></li>
					</ul>
				</div>
			</div>
			<div class="col-xs-6 col-md-4">
				<div class="stbox" >
					<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo6.jpg" /></a>
					<ul>
						<li><p>SM Toy Kingdom</p></li>
						<li><p>Planet Sports</p></li>
						<li><p>Island Souvenirs</p></li>
						<li><p>R.O.X.</p></li>
						<li><p>Chris Sports</p></li>
						<li><p>Dash</p></li>
						<li><p>Lazada Philippines</p></li>
					</ul>
				</div>
			</div>
		</div>
			
         </div>
		</main><!-- #main -->
	</section><!-- #primary -->
	
	
<?php

 get_footer(); ?>
