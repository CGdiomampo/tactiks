<?php
/**
 * Template Name: Brand Page
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package denali
 */

get_header(); 

wp_reset_postdata();
?>
	

	<section id="blog-loop" class="section-wide" role="main">
	
		<main id="main" class="site-main" role="main">
		<div id="main-content" class="page-content main-content container">
         <h1 class="entry-title"> <?php  _e('Brands')  ?>  </h1>  
	

			<div class="row">
				<div class="col-xs-6 col-md-4">
					<div class="brbox" >
						<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo1.jpg" /></a>
						<p>
						For over 30 years, Aerobie brand have become famous for their high performance sport toys. Aerobie products are featured in both large and small retailers throughout the United States and sold in over 35 countries around the world. The unique patented designs and exceptional performance of Aerobie products are widely recognized. They have been prominently featured on national television and in the press and have been singled out for numerous design and performance awards. Most notably, the Aerobie Pro flying ring set the Guinness World Record for the farthest throw – it flew an incredible 1,333 feet (406 meters).</p>
					</div>
				</div>
				<div class="col-xs-6 col-md-4">
					<div class="brbox" >
						<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo2.jpg" /></a>
						<p>
						The AeroPress is the first coffee maker that combines affordability and simplicity with the ability to produce top quality coffee. Simply use this innovative device with your favourite coffee and you’ll never be without that extra special cup. With its versatile brewing technique you can explore the wonders of the world of coffee. Whether you just want a fast, effective way to make a ‘real’ cup of coffee or fancy tinkering with the subtleties of coffee brewing, the AeroPress® Coffee Maker can deliver.</p>
					</div>
				</div>
				<div class="col-xs-6 col-md-4">
					<div class="brbox" >
						<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo3.jpg" /></a>
						<p>
						Chaser is a brand for young-year-olds geared towards three main activities: Run. Skate. Bike. Run outdoors for throw and catch games. Cruise outside with confidence in your skateboards. Get back on the road and tune up your stride with a bike. Chaser is for young generations to enjoy, have fun, and get outside.</p>
					</div>
				</div>
			</div>

			<div class="row" style="margin-bottom: 21px;">
				<div class="col-xs-6 col-md-4">
					<div class="brbox" >
						<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo4.jpg" /></a>
						<p>
						Shore and Earth is a local outdoor brand for surf, swim, and beach accessories.
Endless highways, the sunny beach air, and vibrant mountaintops are just a few things that that inspire Shore and Earth. Shore and Earth accessories are for that weekend adventure from the lands to the sea. Every weekend warrior who loves the outdoor and beach needs quality travel goods and accessories. An ode to love for travel and adventure, each piece of Shore and Earth accessories is unique, craftily styled and hard wearing.</p>
					</div>
				</div>
				<div class="col-xs-6 col-md-4">
					<div class="brbox" >
						<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo5.jpg" /></a>
						<p>
						Tactics Water Gear is a store concept carrying waterproof and water-resistant bags, apparel, and accessories gearing up customers for their many adventures; integrating security in their lifestyle. Whether going to the beach, hiking, swimming, boating, or commuting, Tactics Water Gear will help you “get limitless.”</p>
					</div>
				</div>
				<div class="col-xs-6 col-md-4">
					<div class="brbox" >
						<a href="#"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/brands/logo6.jpg" /></a>
						<p>
						WinMax Sports is an extensive line of sporting items that will surely cater to any of your sporting needs. Whether it be outdoor sports, indoor games, beach and water games, diving, or surfing equipment, WinMax has got what you need for your passion or game. This sporting brand has got your back even when it comes to training and exercise. It has all the equipment you need from jumping ropes, to weights, to yoga mats, running accessories, different kinds of sports gloves, joint and muscle supports and many more! This sporting brand aims to introduce different kinds of popular sports and games to anyone and everyone, from casual fans to hardcore fanatics, and give them top quality sporting goods with impeccable service. Whether for leisure or pursuing your strong passion, WinMax will provide you with the things you need.</p>
					</div>
				</div>
			</div>
		
			<div style="clear:both;"></div>
			
         </div>
		</main><!-- #main -->
	</section><!-- #primary -->
	
	
<?php

 get_footer(); ?>
